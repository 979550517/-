import gzip
import logging
import sys


def read_txt(x):

    logging.info('read txt file')
    txt = []
    if x.endswith('.gz'):
        f = gzip.open(x)
    else:
        f = open(x,encoding='utf-8')
    for line in f:
        if isinstance(line, bytes):
            line = line.decode('utf-8')
        if not line:
            continue
        txt.append(line)

    logging.info('over read txt file')
    return txt


def out(txt):
    logging.info('Prepare the output')
    path=""
    content=""
    cata=""
    file=""
    a=0
    del(txt[0])
    for i in txt:
        i = i.strip()
        line = i.split(sep="\t")
        if len(line) >= 2:
            cata=line[0]
            file=line[1]
            if a==0:
                file1 = file[0:(len(file) - 3)]
                file = file[0:(len(file) - 3)] + "_new"
                path1 =cata + '/' + file1
                path = cata + '/' + file
                #temp=f"cat path1 | awk '{print$1}' | sed '1i id'| paste path"
                temp="cat "+path1+" | awk '"+"{print$1"+"}' | "+"sed '1i ID' > "+cata+"/temp"
                content ="paste "+cata+"/temp"+" "+path+" "
                a=1
            else:
                file=file[0:(len(file)-3)]+"_new"
                path = cata+'/'+file
                content=content+path+" "
        else:
            raise Exception("文件分割错误")
    content.strip()
    print(temp)
    print(content)



    logging.info('The output is complete')


def log_configuration_console():
    logging.basicConfig(
        stream=sys.stderr,
        level=logging.INFO,
        format="%(asctime)s - %(filename)s - %(levelname)s: %(message)s"
    )


def main():
    log_configuration_console()
    file = sys.argv[1]
    txt = read_txt(file)
    out(txt)


if __name__ == '__main__':
    main()