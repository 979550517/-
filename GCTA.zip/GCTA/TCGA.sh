#！/bin/bash
#Author: Creadte bu Liu Pinbo
#version:1.0.0
set -exv
echo Start_SOP
date
LU=`pwd`
XZ=${LU}'/'download
cd $XZ
H:/gcd-client/gdc-client.exe download -m ../$1
cd $LU
F:/基本安装包/python/Scripts/python.exe unzip.py $1 > zip.sh
F:/基本安装包/python/Scripts/python.exe raw_data_title.py $1 > raw.sh
F:/基本安装包/python/Scripts/python.exe merge.py $1 > merge.sh
cd $XZ
bash ../zip.sh
bash ../raw.sh
bash ../merge.sh > ../raw_data.txt
date
echo End_SOP