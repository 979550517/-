import gzip
import logging
import sys


def read_txt(x):

    logging.info('read txt file')
    txt = []
    if x.endswith('.gz'):
        f = gzip.open(x)
    else:
        f = open(x,encoding='utf-8')
    for line in f:
        if isinstance(line, bytes):
            line = line.decode('utf-8')
        if not line:
            continue
        txt.append(line)

    logging.info('over read txt file')
    return txt


def out(txt):
    logging.info('Prepare the output')
    content=""
    del(txt[0])
    for i in txt:
        i=i.strip()
        line=i.split(sep="\t")
        content=content+'gunzip'+" "+line[0]+"/"+line[1]+'\n'
    content=content.strip()

    logging.info('The output is complete')
    return content


def log_configuration_console():
    logging.basicConfig(
        stream=sys.stderr,
        level=logging.INFO,
        format="%(asctime)s - %(filename)s - %(levelname)s: %(message)s"
    )


def main():
    log_configuration_console()
    file = sys.argv[1]
    txt = read_txt(file)
    content = out(txt)
    print(content)


if __name__ == '__main__':
    main()